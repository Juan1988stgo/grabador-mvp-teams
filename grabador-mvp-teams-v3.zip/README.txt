1. Subir este proyecto a un nuevo repo en GitHub
2. Hacer deploy desde Railway usando Dockerfile
3. Cargar las variables de entorno del .env.example
4. Subir credentials.json a Railway (Google OAuth)
5. Disfrutar de grabación automática en Teams