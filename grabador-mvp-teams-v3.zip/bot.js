// Placeholder: Opens link with Puppeteer
console.log("Abriendo Teams...");